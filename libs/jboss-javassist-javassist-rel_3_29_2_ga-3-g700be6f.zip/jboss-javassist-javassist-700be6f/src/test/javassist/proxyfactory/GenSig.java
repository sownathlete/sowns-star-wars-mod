package javassist.proxyfactory;

class GenSig<T> {
}
