package test1;

public class StaticField {
    public static int counter;
}
