package test2;

public class AddMethod {
    @SuppressWarnings("unused")
    private int f;

    public int f() { return 0; }
    public AddMethod() {}
    public int f(int i) { return i; }
}
