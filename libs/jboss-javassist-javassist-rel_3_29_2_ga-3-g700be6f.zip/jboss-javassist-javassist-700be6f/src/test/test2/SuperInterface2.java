package test2;

public interface SuperInterface2 extends SuperInterface1 {}
