package test3;

@ChibaAnnotation(name="Chiba",version="Chiba",description="Chiba",interfaceName="Chiba")
public class NewClass2 {
}